package com.meme.predictor

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import okhttp3.*
import org.json.JSONObject
import java.math.BigDecimal
import java.math.RoundingMode
import java.util.concurrent.TimeUnit

private const val WS = "wss://api.derivws.com/trading/v1/options/ws/public"
private val MARKETS = listOf("1HZ10V", "1HZ25V", "1HZ50V", "1HZ75V", "1HZ100V", "R_10", "R_25", "R_50", "R_75", "R_100")
private data class Tick(val price: Double, val digit: Int)
private enum class Mode { RISE_FALL, OVER_UNDER, EVEN_ODD }

class PredictorModel : ViewModel() {
    var market by mutableStateOf("1HZ100V")
    var status by mutableStateOf("Not connected")
    var online by mutableStateOf(false)
    var quote by mutableStateOf("—")
    var digit by mutableStateOf("—")
    var ticks by mutableStateOf(listOf<Tick>())
    var window by mutableIntStateOf(100)
    var barrier by mutableIntStateOf(4)
    var mode by mutableStateOf(Mode.RISE_FALL)
    private var ws: WebSocket? = null
    private val client = OkHttpClient.Builder().pingInterval(20, TimeUnit.SECONDS).readTimeout(0, TimeUnit.MILLISECONDS).build()

    fun connect() {
        ws?.close(1000, "reconnect")
        online = false
        status = "Connecting to Deriv public feed…"
        ws = client.newWebSocket(Request.Builder().url(WS).build(), object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                online = true
                status = "Connected · $market"
                webSocket.send(JSONObject().put("ticks", market).put("subscribe", 1).put("req_id", 1).toString())
            }
            override fun onMessage(webSocket: WebSocket, text: String) {
                try {
                    val root = JSONObject(text)
                    if (root.has("error")) { status = root.getJSONObject("error").optString("message", "Feed error"); return }
                    val t = root.optJSONObject("tick") ?: return
                    val price = t.optDouble("quote", Double.NaN)
                    if (price.isNaN()) return
                    val places = t.optInt("pip_size", BigDecimal.valueOf(price).stripTrailingZeros().scale().coerceAtLeast(0))
                    val formatted = BigDecimal.valueOf(price).setScale(places, RoundingMode.HALF_UP).toPlainString()
                    val lastDigit = formatted.lastOrNull { it.isDigit() }?.digitToIntOrNull() ?: return
                    ticks = (ticks + Tick(price, lastDigit)).takeLast(1000)
                    quote = formatted; digit = lastDigit.toString(); status = "Live · $market"
                } catch (_: Exception) { status = "Receiving ticks…" }
            }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) { online = false; status = "Connection failed: ${t.localizedMessage ?: "check internet"}" }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) { online = false; status = "Disconnected" }
        })
    }
    fun selectMarket(value: String) { if (market == value) return; market = value; ticks = emptyList(); quote = "—"; digit = "—"; connect() }
    private fun sample() = ticks.takeLast(window)
    fun evenShare(): Double? { val a = sample(); return if (a.isEmpty()) null else (a.count { it.digit % 2 == 0 } + 1.0) / (a.size + 2.0) }
    fun overShare(): Double? { val a = sample(); return if (a.isEmpty()) null else (a.count { it.digit > barrier } + 1.0) / (a.size + 2.0) }
    fun riseShare(): Double? {
        val a = sample().map { it.price }; if (a.size < 2) return null
        var up = 0; var down = 0; var tie = 0
        a.zipWithNext().forEach { (x,y) -> when { y > x -> up++; y < x -> down++; else -> tie++ } }
        return (up + tie * 0.5 + 1.0) / (up + down + tie + 2.0)
    }
    override fun onCleared() { ws?.close(1000, "app closed"); client.dispatcher.executorService.shutdown() }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { PredictorScreen() } }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PredictorScreen(vm: PredictorModel = viewModel()) {
    var marketMenu by remember { mutableStateOf(false) }
    MaterialTheme(colorScheme = if (androidx.compose.foundation.isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
        Scaffold(topBar = { TopAppBar(title = { Column { Text("MeMe Predictor"); Text("Deriv Synthetic Indices · Analysis only", style = MaterialTheme.typography.labelSmall) } }) }) { pad ->
            Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Card { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(if (vm.online) "● LIVE" else "○ OFFLINE", color = if (vm.online) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                    Box {
                        OutlinedButton(onClick = { marketMenu = true }, modifier = Modifier.fillMaxWidth()) { Text("Market: ${vm.market}  ▾") }
                        DropdownMenu(expanded = marketMenu, onDismissRequest = { marketMenu = false }) { MARKETS.forEach { s -> DropdownMenuItem(text = { Text(s) }, onClick = { marketMenu = false; vm.selectMarket(s) }) } }
                    }
                    Text(vm.status, style = MaterialTheme.typography.bodySmall)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Metric("LATEST PRICE", vm.quote); Metric("LAST DIGIT", vm.digit); Metric("TICKS", vm.ticks.size.toString()) }
                    if (!vm.online) Button(onClick = { vm.connect() }, modifier = Modifier.fillMaxWidth()) { Text("Connect / Reconnect") }
                } }
                TabRow(selectedTabIndex = vm.mode.ordinal) {
                    listOf("Rise/Fall", "Over/Under", "Even/Odd").forEachIndexed { i, label -> Tab(selected = vm.mode.ordinal == i, onClick = { vm.mode = Mode.values()[i] }, text = { Text(label) }) }
                }
                Card { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("ANALYSIS WINDOW", style = MaterialTheme.typography.labelLarge)
                    Text("${vm.window} recent ticks")
                    Slider(value = vm.window.toFloat(), onValueChange = { vm.window = it.toInt() }, valueRange = 20f..500f, steps = 23)
                    when (vm.mode) {
                        Mode.RISE_FALL -> Signal("Rise / Fall historical direction", vm.riseShare(), "RISE share based on up/down/unchanged consecutive tick movements. It is not a next-tick forecast.")
                        Mode.OVER_UNDER -> {
                            Text("Over threshold: ${vm.barrier}")
                            Slider(value = vm.barrier.toFloat(), onValueChange = { vm.barrier = it.toInt() }, valueRange = 0f..8f, steps = 7)
                            Signal("Digit Over ${vm.barrier}", vm.overShare(), "Over means last digit strictly greater than ${vm.barrier}; Under means less than or equal to ${vm.barrier}.")
                        }
                        Mode.EVEN_ODD -> Signal("Even digit share", vm.evenShare(), "Odd digit share: ${vm.evenShare()?.let { pct(1.0-it) } ?: "waiting for ticks"}. Frequencies are descriptive, not predictive.")
                    }
                } }
                Card { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { Text("LAST 20 DIGITS", style = MaterialTheme.typography.labelLarge); Text(vm.ticks.takeLast(20).joinToString("  ") { it.digit.toString() }.ifBlank { "Waiting for first ticks…" }, style = MaterialTheme.typography.titleMedium) } }
                Text("Risk notice: Synthetic Index outcomes may be unpredictable. These are historical sample statistics, not guaranteed or reliable predictions. No trades are placed.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                Text("Live data uses Deriv's public market-data WebSocket. Internet required.", style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable private fun Metric(label: String, value: String) { Column { Text(label, style = MaterialTheme.typography.labelSmall); Text(value, style = MaterialTheme.typography.titleMedium) } }
@Composable private fun Signal(title: String, p: Double?, note: String) {
    Text(title, style = MaterialTheme.typography.titleMedium)
    if (p == null) { Text("Waiting for enough live ticks…"); LinearProgressIndicator(Modifier.fillMaxWidth()) }
    else { Text("Estimated historical share: ${pct(p)}", style = MaterialTheme.typography.headlineSmall); LinearProgressIndicator(progress = { p.toFloat() }, modifier = Modifier.fillMaxWidth()); Text("Other side: ${pct(1.0-p)}") }
    Text(note, style = MaterialTheme.typography.bodySmall)
}
private fun pct(v: Double) = String.format("%.1f%%", v * 100.0)
