# MeMe Predictor — Android Studio source project

Native Android starter app for read-only Deriv Synthetic Indices analysis.

## Features
- Public Deriv tick stream over secure WebSocket
- Market selector for a starter set of synthetic symbols
- Rise/Fall historical direction share
- Digit Over/Under historical frequency with adjustable threshold
- Digit Even/Odd historical frequency
- Adjustable sample window and recent digit display
- No trading, account login, API token, or order placement

## Build an APK
1. Install Android Studio and Android SDK 35.
2. Open this folder in Android Studio and allow Gradle sync.
3. Connect an Android phone (USB debugging enabled) or start an emulator.
4. Press **Run** to install the debug app.
5. To create an APK, choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Data connection
Connects to `wss://api.derivws.com/trading/v1/options/ws/public` and subscribes to the selected symbol's tick stream. Public market data does not require account authentication.

## Important limitations
- This ZIP contains Android Studio source code, not a compiled/signed APK.
- It has not been compiled or tested on a physical Android device in this environment.
- The market list is a starter list; verify symbols are currently active. A production version should populate the list from Deriv's `active_symbols` endpoint.
- The last digit is read from the formatted quote using `pip_size` where supplied; verify formatting for each market against Deriv's displayed quote.
- Rise/Fall is the observed proportion of upward/downward/unchanged tick-to-tick moves. Over/Under and Even/Odd are Laplace-smoothed historical frequencies. None is a validated next-outcome prediction model.
- Connection lifecycle/background reconnection and extensive device testing are still needed before release.

## Official references
- https://developers.deriv.com/docs/intro/api-overview/
- https://developers.deriv.com/docs/data/ticks/
- https://developers.deriv.com/docs/data/ticks-history/

## Build the APK in the cloud (no computer needed after repository setup)
This project includes `.github/workflows/android.yml`. GitHub Actions can compile a debug APK in a hosted runner.

1. Create a GitHub account and a new repository named `MeMePredictor`.
2. Upload the extracted project files to the repository (the `.github/workflows/android.yml` file must be included) and commit them to `main`.
3. Open the repository in a browser, select **Actions**, then **Build MeMe Predictor APK**, and tap **Run workflow** if it has not started automatically.
4. When the run completes successfully, open the run and download the **MeMe-Predictor-debug-APK** artifact.
5. Extract the artifact ZIP on your Android phone and tap `app-debug.apk` to install. Android may ask you to allow installs from that browser or file manager.

This workflow produces an unsigned debug APK for personal testing, not a Play Store release. The workflow itself has not been run in this environment, so a successful build is not yet confirmed.
